package actividad.pkg7;
public class Actividad7 {
public static void main(String[] args) {
    Primos op = new Primos();
    op.leer();
    op.primo();
    
    Fibonacci fi = new Fibonacci();
    
    
    
    }
}
