package actividad.pkg7;
import java.util.Scanner;
public class Primos {
   //Atributos
    int n,num,j,x,cont;
    int [] array = new int [n];

    //Método para ingresar datos
    public void leer(){
    Scanner leer = new Scanner (System.in);
    System.out.println("Ingrese cuantos números desea buscar");
        n = leer.nextInt();
    }
    
    //Métodos
    public void primo(){
    num=0;
        while(n > 0){
            num = num +1;
            x = 1;
            cont = 0;
            while(x <= num){
                //j = num % x;
                if (num%x == 0){
                    cont = cont + 1;
                }
                x = x + 1;
            }
            if(cont == 2){
              System.out.println("El número " + num + " es primo");
                n = n - 1;
            }
        }    
    }   
}
